/**
 * SpatialNotation
 * Spatial/graphical music notation library.
 * http://github.com/p1nh0/SpatialNotation
 *
 * Copyright (C) 2013 Tiago_Ângelo http://github.com/p1nh0
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author      Tiago_Ângelo http://github.com/p1nh0
 * @modified    04/14/2013
 * @version     0.1.1 (1)
 */

package spatialnotation;

import processing.core.PApplet;

/**
 * You need to instantiate this class before using other classes from spatnot library. 
 * 
 * @example spatnot-Skeleton  
 * 
 *
 */
public class SnAPI{
	static PApplet parent;
	
	/**
	 * You need to pass the variable 'this' to the class constructor 
	 * 
	 * @param parent
	 */
	public SnAPI(PApplet p ){
		parent=p; 
		welcome(); 
	}
	public SnAPI() { // empty constructor for other classes to access???
		
	}
	
	private void welcome() {
		System.out.println("SpatialNotation 0.1.1 by Tiago_Ângelo http://github.com/p1nh0");
	}
	
	public static PApplet getParent(){
		return parent; 
	}
}
