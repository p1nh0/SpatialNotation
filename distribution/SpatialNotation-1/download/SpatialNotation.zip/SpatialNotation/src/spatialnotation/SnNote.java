package spatialnotation;

public class SnNote {

}
